<?php include('public_header.php'); ?>


<div class='container'>
  <?php echo form_open('users/login'); ?>
  <fieldset>
    <legend>LOGIN</legend>
    <div class="form-group">
      <label for="exampleInputEmail1">Email address</label>
      <?php 
      $attributes = array('name'=>'email', 'class' => 'form-control', 'id' => 'exampleInputEmail1', 'aria-describedby'=>'emailHelp', 'placeholder'=>'Enter email', 'value'=>set_value('email'));
      echo form_input($attributes); ?>
      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <?php 
      $attributes = array('name'=>'password', 'type'=>'password', 'class' => 'form-control', 'id' => 'exampleInputPassword1', 'placeholder'=>'Password');
      echo form_input($attributes); ?>
    </div>
    <?php 
      $attributes = array('type'=>'reset', 'class' => 'btn btn-secondary', 'value'=>'Reset');
      echo form_reset($attributes);
      $attributes = array('type'=>'submit', 'class' => 'btn btn-primary', 'value'=>'Submit'); 
      echo form_submit($attributes);
      
      echo validation_errors();
      ?>

  </fieldset>
</form>
<div>


<?php include('public_footer.php'); ?>