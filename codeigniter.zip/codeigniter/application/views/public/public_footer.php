<script type="text/javascript" src="<?= base_url('assets/js/jquery.min.js'); ?>"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.5/umd/popper.min.js"></script> 
</body>
</html>