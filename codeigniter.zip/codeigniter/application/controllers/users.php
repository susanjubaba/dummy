<?php defined('BASEPATH') OR exit('No direct script access allowed');


class Users extends My_Controller
{
	public function index()
	{
		$this->load->helper('form');
		$this->load->view('public/users_view');
	}
	public function login()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('email', 'Email ID', 'required|trim');
		$this->form_validation->set_rules('password', 'Password', 'required');
		if($this->form_validation->run()){
			echo "Successful";
		}else{
			$this->load->view('public/users_view');			
		}
	}
}