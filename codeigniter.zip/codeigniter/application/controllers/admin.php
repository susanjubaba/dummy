<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends My_Controller
{
	public function index()
	{
		echo 'this is admin section';
	}
}